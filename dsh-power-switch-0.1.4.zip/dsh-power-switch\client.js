window.__ModuleLoader__.load({
  id: 'dsh-power-switch',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useCallback, useEffect, useState } = React

    const API = '/dsh-power-switch/api'
    const BUTTON_SLOT = 'conversation.session.header.utilities'
    const PANEL_SLOT = 'shell.overlay'

    /* ── 按钮和菜单住在两个 slot 里，靠这一点点共享状态串起来 ─────────── */
    let panelOpen = false
    const listeners = new Set()
    const setPanelOpen = (next) => {
      if (panelOpen === next) return
      panelOpen = next
      for (const listener of [...listeners]) {
        try {
          listener(panelOpen)
        } catch {
          /* 一个订阅者崩了不该冻住开关 */
        }
      }
    }
    const usePanelOpen = () => {
      const [open, setOpen] = useState(panelOpen)
      useEffect(() => {
        listeners.add(setOpen)
        setOpen(panelOpen)
        return () => listeners.delete(setOpen)
      }, [])
      return open
    }

    const CSS = `
.dpsw-trigger {
  display: inline-flex; align-items: center; justify-content: center; pointer-events: auto;
  width: 28px; height: 28px; padding: 0; border-radius: 8px;
  border: 1px solid transparent; background: transparent; cursor: pointer;
  color: var(--dsw-alias-label-secondary);
  transition: background 120ms ease, color 120ms ease, border-color 120ms ease;
}
.dpsw-trigger:hover { color: var(--dsw-alias-label-primary); background: var(--dsw-alias-bg-layer-2); }
.dpsw-trigger[data-open="true"] { color: var(--dsw-alias-brand-primary); background: var(--dsw-alias-bg-layer-2); border-color: var(--dsw-alias-border-l1); }
.dpsw-trigger:focus-visible { outline: 2px solid var(--dsw-alias-brand-primary); outline-offset: 1px; }
/* shell.overlay 本身点击穿透：面板自己把点击要回来 */
.dpsw-scrim { position: fixed; inset: 0; z-index: 40; background: transparent; pointer-events: auto; }
.dpsw-menu {
  position: fixed; z-index: 41; right: 12px; pointer-events: auto;
  display: flex; flex-direction: column; gap: 6px; width: 168px; padding: 8px;
  background: var(--dsw-alias-bg-overlay); color: var(--dsw-alias-label-primary);
  border: 1px solid var(--dsw-alias-border-l1); border-radius: 10px;
  box-shadow: 0 10px 28px rgba(0,0,0,.16);
  animation: dpsw-drop 120ms ease-out;
}
@keyframes dpsw-drop { from { transform: translateY(-4px); opacity: .7 } to { transform: none; opacity: 1 } }
.dpsw-menu[data-dir="up"] { animation-name: dpsw-rise; }
@keyframes dpsw-rise { from { transform: translateY(4px); opacity: .7 } to { transform: none; opacity: 1 } }
.dpsw-btn {
  appearance: none; display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  min-height: 30px; padding: 0 10px; border-radius: 8px; cursor: pointer;
  font: inherit; font-size: 12px; white-space: nowrap;
  border: 1px solid var(--dsw-alias-border-l2); background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-primary); transition: filter 120ms ease, transform 60ms ease;
}
.dpsw-btn:hover { filter: brightness(1.06); }
.dpsw-btn:active { transform: translateY(1px); }
.dpsw-btn:disabled { opacity: .55; cursor: progress; }
.dpsw-btn.restart { border-color: var(--dsw-alias-brand-primary); color: var(--dsw-alias-brand-primary); }
.dpsw-btn.shutdown { border-color: var(--dsw-alias-state-error-primary); color: var(--dsw-alias-state-error-primary); }
.dpsw-btn.armed { background: var(--dsw-alias-state-error-primary); color: #fff; border-color: transparent; }
.dpsw-err { font-size: 11px; line-height: 1.4; color: var(--dsw-alias-state-error-primary); text-align: center; }
.dpsw-busy { font-size: 11.5px; line-height: 1.4; color: var(--dsw-alias-label-secondary); text-align: center; }
`

    const Icon = ({ open }) =>
      h(
        'svg',
        {
          viewBox: '0 0 24 24',
          width: 16,
          height: 16,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: open ? 2.1 : 1.9,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
        },
        h('path', { d: 'M12 3v9' }),
        h('path', { d: 'M7.1 6.1a7 7 0 1 0 9.8 0' }),
      )

    function PowerTrigger() {
      const open = usePanelOpen()
      return h(
        'button',
        {
          type: 'button',
          className: 'dpsw-trigger',
          'data-open': open ? 'true' : 'false',
          title: '电源开关 ⚡',
          'aria-label': '电源开关',
          'aria-expanded': open ? 'true' : 'false',
          onClick: () => setPanelOpen(!open),
        },
        h(Icon, { open }),
      )
    }

    /* 只有两个按钮，没有别的说明 */
    function PowerMenu() {
      const open = usePanelOpen()
      const [armed, setArmed] = useState(null)
      const [busy, setBusy] = useState(false)
      const [error, setError] = useState(null)
      const [hint, setHint] = useState(null)
      /* 面板贴着按钮出现；下方放不下就向上翻。不写死坐标，免得换个窗口大小就跑偏 */
      const [pos, setPos] = useState(null)

      useEffect(() => {
        if (!open) {
          setArmed(null)
          setError(null)
          setHint(null)
          setPos(null)
          return undefined
        }
        const place = () => {
          const trigger = document.querySelector('.dpsw-trigger')
          const menu = document.querySelector('.dpsw-menu')
          const menuHeight = menu === null ? 140 : menu.offsetHeight
          const gap = 6
          if (trigger === null) {
            setPos({ top: 44, right: 12, dir: 'down' })
            return
          }
          const rect = trigger.getBoundingClientRect()
          const right = Math.max(8, window.innerWidth - rect.right)
          const below = window.innerHeight - rect.bottom
          if (below < menuHeight + gap + 8 && rect.top > menuHeight + gap + 8) {
            setPos({ top: Math.round(rect.top - menuHeight - gap), right: Math.round(right), dir: 'up' })
          } else {
            setPos({ top: Math.round(rect.bottom + gap), right: Math.round(right), dir: 'down' })
          }
        }
        place()
        const onResize = () => place()
        window.addEventListener('resize', onResize)
        const onKey = (event) => {
          if (event.key === 'Escape') setPanelOpen(false)
        }
        window.addEventListener('keydown', onKey)
        return () => {
          window.removeEventListener('resize', onResize)
          window.removeEventListener('keydown', onKey)
        }
      }, [open])

      const act = useCallback(async (action) => {
        setBusy(true)
        setError(null)
        setHint(null)
        try {
          const res = await fetch(`${API}?action=${action}`, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ action }),
          })
          const data = await res.json().catch(() => ({}))
          if (!res.ok || data.ok !== true) {
            setError('没成功 😵')
            setBusy(false)
            return
          }
          setHint(action === 'shutdown' ? '正在关闭 🌙' : '正在重启 ⚡')

          // 这个页面跟着旧进程一起消失，不需要轮询也不需要刷新。
          // 如果十几秒后还活着，说明那一下没生效。
          for (let i = 0; i < 16; i += 1) {
            await new Promise((r) => setTimeout(r, 1_000))
            try {
              await fetch(`${API}?action=ping`, { credentials: 'same-origin', cache: 'no-store' })
            } catch {
              // 请求打不通了 —— 进程正在走，这就是预期结果
              return
            }
          }
          setError('没反应，再点一次？🤔')
          setBusy(false)
        } catch {
          setError('没成功 😵')
          setBusy(false)
        }
      }, [])

      if (!open) return null

      const confirm = (action) => {
        if (armed === action) {
          setArmed(null)
          void act(action)
          return
        }
        setArmed(action)
        setError(null)
      }

      return h(
        React.Fragment,
        null,
        h('div', { className: 'dpsw-scrim', onClick: () => setPanelOpen(false), 'aria-hidden': true }),
        h(
          'div',
          {
            className: 'dpsw-menu',
            role: 'menu',
            'data-dir': pos === null ? 'down' : pos.dir,
            style:
              pos === null
                ? { top: 44, right: 12 }
                : { top: `${pos.top}px`, right: `${pos.right}px` },
          },
          h('style', null, CSS),
          busy ? h('div', { className: 'dpsw-busy' }, '处理中… ⏳') : null,
          h(
            'button',
            {
              type: 'button',
              role: 'menuitem',
              className: `dpsw-btn restart${armed === 'restart' ? ' armed' : ''}`,
              disabled: busy,
              onClick: () => confirm('restart'),
            },
            armed === 'restart' ? '确认重启？再点一下' : '⚡ 重启',
          ),
          h(
            'button',
            {
              type: 'button',
              role: 'menuitem',
              className: `dpsw-btn shutdown${armed === 'shutdown' ? ' armed' : ''}`,
              disabled: busy,
              onClick: () => confirm('shutdown'),
            },
            armed === 'shutdown' ? '确认关闭？再点一下' : '⏻ 关闭',
          ),
          hint !== null ? h('div', { className: 'dpsw-busy' }, hint) : null,
          error !== null ? h('div', { className: 'dpsw-err' }, error) : null,
        ),
      )
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        ctx.slots.inject(BUTTON_SLOT, () =>
          ctx.slots.register({ name: BUTTON_SLOT, id: 'dsh-power-switch', order: 90 }, PowerTrigger),
        )
        ctx.slots.inject(PANEL_SLOT, () =>
          ctx.slots.register({ name: PANEL_SLOT, id: 'dsh-power-switch.panel', order: 90 }, PowerMenu),
        )
      },
    }
  },
})
